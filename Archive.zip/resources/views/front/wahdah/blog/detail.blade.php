@extends('front.wahdah.layouts.main')

@section('title', @$menus->menu_title.' | '.$setting->meta_title)
@section('keyword', $setting->meta_keyword)
@section('description',  $setting->meta_description)

@section('contents')
	<section class="heading first">
		<div class="container">
			<h1 class="title title-detail">{{ $post->title }}</h1>
			<div class="tag">{{ $post->category }}</div>
		</div>
	</section>

	<section class="article-detail">
		<div class="container">
			<div class="row content justify-content-between">
				<div class="col-md-8">
					<div class="author">
						<div class="photo" style="background-image: url({{ asset('uploaded') }}/{{ $post->photo }});"></div>
						<div class="name">{{ $post->fullname }}</div>
						<div class="date">{{ date('d M Y',strtotime($post->published)) }}</div>
					</div>
					<img class="img" src="{{ asset('uploaded') }}/thumb-{{ $post->image }}" alt="{{ $post->title }}" width="100%">
					{!! $post->content !!}
				</div>
				<div class="col-md-4">
					<h4>Baca Juga</h4>

					<div class="read-to">
						<br>
						@foreach ($recent_posts as $rp)
						<article class="item">
							<div class="img" style="background-image: url({{ asset('uploaded') }}/{{ $rp->image }});"></div>
							<div class="caption">
								<h3 class="title"><a href="{{ route('front_blog_detail', ['slug' => $rp->slug ]) }}">{{ $rp->title }}</a></h3>
								<div class="tag">{{ $rp->category }} . <span class="date">12 Oktober 2017</span></div>
							</div>
						</article>
						@endforeach
					</div>
				</div>
			</div>
		</div>
	</section>
@endsection