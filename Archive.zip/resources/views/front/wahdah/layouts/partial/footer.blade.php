<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-sm-4 col-xs-4">
				<a class="footer-brand" href="{{ route('front_home') }}"><img src="{{ asset('uploaded') }}/{{ $setting->logo }}" alt="Logo Wahdah Islamiyah"><span>Wahdah Islamiyah Makassar</span></a>
			</div>
			<div class="col-md-4 col-sm-8 col-xs-8">
				<div class="contact">
					<ul class="list-unstyled">
						<li>
							<i class="fa fa-map"></i>
							<div class="content">
								{{ $setting->address }}
							</div>
						</li>
						<li>
							<i class="fa fa-phone"></i>
							<div class="content">
								<b>{{ $setting->phone }}</b>
							</div>
						</li>
						<li>
							<i class="fa fa-envelope"></i>
							<div class="content">
								<a href="mailto:{{ $setting->email }}"><b>{{ $setting->email }}</b></a>
							</div>
						</li>
						<li>
							<ul class="list-inline sosmed">
								@if ($setting->facebook != "")
									<li class="list-inline-item"><a href="https://www.facebook.com/{{ $setting->facebook }}" target="_blank"><i class="fa fa-facebook"></i></a></li>
								@endif

								@if ($setting->twitter != "")
									<li class="list-inline-item"><a href="https://twitter.com/{{ $setting->twitter }}" target="_blank"><i class="fa fa-twitter"></i></a></li>
								@endif

								@if ($setting->linkedin != "")
									<li class="list-inline-item"><a href="https://www.linkedin.com/{{ $setting->linkedin }}" target="_blank"><i class="fa fa-linkedin"></i></a></li>
								@endif

								@if ($setting->google != "")
									<li class="list-inline-item"><a href="https://plus.google.com/{{ $setting->google }}" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								@endif

								@if ($setting->instagram != "")
									<li class="list-inline-item"><a href="https://www.instagram.com/{{ $setting->instagram }}" target="_blank"><i class="fa fa-instagram"></i></a></li>
								@endif

								@if ($setting->youtube != "")
									<li class="list-inline-item"><a href="https://www.youtube.com/{{ $setting->youtube }}" target="_blank"><i class="fa fa-youtube"></i></a></li>
								@endif
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>