<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-light"">
	<div class="container">
		<a class="navbar-brand" href="{{ route('front_home') }}"><img src="{{ asset('uploaded') }}/{{ $setting->logo }}" alt="Logo Wahdah Islamiyah"><span><b>Wahdah Islamiyah</b> Makassar</span></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				@foreach ($nav->where('parent', '0') as $menu)
					<li class="nav-item dropdown {{ $_SERVER['REQUEST_URI'] == $menu->url ? 'active' : '' }}">
						@forelse ($subs->where('parent', $menu->id)->take(1) as $sub)
							<a class="nav-link dropdown-toggle" href="{{ $menu->url }}" data-toggle="dropdown" onclick="window.location.href = '{{ $menu->url }}';">{{ $menu->menu_title }}&nbsp;</a>
						@empty
							<a class="nav-link" href="{{ $menu->url }}">{{ $menu->menu_title }}&nbsp;</a>
						@endforelse
						
						@if (count($nav->where('parent', $menu->id)) > 0)
							<div class="dropdown-menu">
								@foreach ($nav->where('parent', $menu->id) as $menu)
									<a class="dropdown-item" href="{{ $menu->url }}">{{ $menu->menu_title }}</a>
								@endforeach
							</div>
						@endif
					</li>
				@endforeach
			</ul>

			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link nav-button" href="#">Langganan</a>
				</li>
			</ul>
		</div>
	</div>
</nav>