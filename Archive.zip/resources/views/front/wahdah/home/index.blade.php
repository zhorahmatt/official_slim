@extends('front.wahdah.layouts.main')

@section('title', $menus->menu_title.' | '.$setting->meta_title)
@section('keyword', $setting->meta_keyword)
@section('description', $setting->meta_description)

@section('contents')
	@if ($slideshow)
		<section class="slide first">
			<div class="owl-carousel">
				@foreach ($slideshow as $key => $slide)
					<div class="slide-item" style="background-image: url({{ asset('uploaded') }}/{{ $slide->image }})">
						<div class="slide-overlay"></div>
						<div class="container">
							<div class="slide-caption">
								<h2 class="title"><a href="{{ $slide->link }}">{{ $slide->title }}</a></h2>
								<h5 class="tag">{!! $slide->desc !!}</h5>
							</div>
						</div>
					</div>
				@endforeach
			</div>
		</section>
	@endif

	<section class="featured">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="article-featured" style="background-image: url({{ asset('uploaded') }}/{{ $posts[0]->image }});">
						<div class="tag">{{ $posts[0]->category }}</div>
						<div class="caption">
							<h3 class="title"><a href="{{ route('front_blog_detail', ['slug' => $posts[0]->slug]) }}">{{ $posts[0]->title }}</a></h3><br>
							<span class="date">{{ date('d M Y',strtotime($posts[0]->published)) }}</span>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="article-featured-2">
						<div class="img" style="background-image: url({{ asset('uploaded') }}/{{ $posts[1]->image }});"></div>
						<div class="caption">
							<div class="tag">{{ $posts[1]->category }}</div>
							<h3 class="title"><a href="{{ route('front_blog_detail', ['slug' => $posts[1]->slug]) }}">{{ $posts[1]->title }}</a></h3><br>
							<span class="date">{{ date('d M Y',strtotime($posts[1]->published)) }}</span>
						</div>
						<div class="clearfix"></div>
					</div>

					<div class="article-featured-2">
						<div class="img" style="background-image: url({{ asset('uploaded') }}/{{ $posts[2]->image }});"></div>
						<div class="caption">
							<div class="tag">{{ $posts[2]->category }}</div>
							<h3 class="title"><a href="{{ route('front_blog_detail', ['slug' => $posts[2]->slug]) }}">{{ $posts[2]->title }}</a></h3><br>
							<span class="date">{{ date('d M Y',strtotime($posts[2]->published)) }}</span>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="articles">
		<div class="heading">Kajian</div>
		<div class="container">
			@for ($i = 3; $i < 6; $i++)
				<article class="item">
					<div class="row">
						<div class="col-md-8">
							<div class="tag">{{ $posts[$i]->category }}</div>
							<h3 class="title ellipsis"><a href="{{ route('front_blog_detail', ['slug' => $posts[$i]->slug]) }}">{{ $posts[$i]->title }}</a></h3>
							<p class="desc">{{ strip_tags(substr($posts[$i]->content, 0, 150)) }}...</p>
							<div class="author">
								<div class="photo" style="background-image: url({{ asset('uploaded') }}/{{ $posts[$i]->photo }});"></div>
								<div class="name">{{ $posts[$i]->fullname }}</div>
								<div class="date">{{ date('d M Y',strtotime($posts[$i]->published)) }}</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="img" style="background-image: url({{ asset('uploaded') }}/{{ $posts[$i]->image }});"></div>
						</div>

						<div class="col-md-12">
							<div class="separator"></div>
						</div>
					</div>
				</article>
			@endfor
		</div>
	</section>
	
	<div class="banner">
		<div class="container">
			<h2 class="title">Naskah Khutbah</h2>
			<p class="desc">Silahkan klik tautan di bawah untuk mengakses naskah-naskah khutbah pilihan kami</p>
			<a href="blog.html" class="link">Kunjungi Sekarang &nbsp;<i class="fa fa-arrow-right"></i></a>
		</div>
	</div>

	<section class="articles">
		<div class="heading heading-after-banner">Berita</div>
		<div class="container">
			@for ($i = 0; $i < 3; $i++)
				<article class="item">
					<div class="row">
						<div class="col-md-8">
							<div class="tag">{{ $news[$i]->category }}</div>
							<h3 class="title ellipsis"><a href="{{ route('front_news_detail', ['slug' => $news[$i]->slug]) }}">{{ $news[$i]->title }}</a></h3>
							<p class="desc">{{ strip_tags(substr($news[$i]->content, 0, 150)) }}...</p>
							<div class="author">
								<div class="photo" style="background-image: url({{ asset('uploaded') }}/{{ $news[$i]->photo }});"></div>
								<div class="name">{{ $news[$i]->fullname }}</div>
								<div class="date">{{ date('d M Y',strtotime($news[$i]->published)) }}</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="img" style="background-image: url({{ asset('uploaded') }}/{{ $news[$i]->image }});"></div>
						</div>

						<div class="col-md-12">
							<div class="separator"></div>
						</div>
					</div>
				</article>
			@endfor
		</div>
	</section>

@endsection