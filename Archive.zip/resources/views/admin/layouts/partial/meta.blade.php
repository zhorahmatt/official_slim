<meta charset="utf-8" />
<title>CMS Media SAKTI</title>
<meta name="description" content="app, web app, responsive, responsive layout, admin, admin panel, admin dashboard, flat, flat ui, ui kit, AngularJS, ui route, charts, widgets, components" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/assets/animate.css/animate.css" type="text/css" />
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/assets/font-awesome/css/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/assets/simple-line-icons/css/simple-line-icons.css" type="text/css" />
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />

<link rel="stylesheet" href="{{ asset('assets') }}/admin/css/font.css" type="text/css" />
<link rel="stylesheet" href="{{ asset('assets') }}/admin/css/app.css" type="text/css" />

<!-- Editor -->
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/froala_editor.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/froala_style.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/code_view.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/colors.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/emoticons.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/image_manager.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/image.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/line_breaker.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/table.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/char_counter.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/video.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/fullscreen.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/file.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/plugins/quick_insert.css">
<link rel="stylesheet" href="{{ asset('assets') }}/admin/libs/jquery/froala/css/themes/custom-theme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.css">