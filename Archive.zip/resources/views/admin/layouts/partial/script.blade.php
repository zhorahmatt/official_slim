<script src="{{ asset('assets') }}/admin/libs/jquery/jquery/dist/jquery.js"></script>
<script src="{{ asset('assets') }}/admin/libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-load.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-jp.config.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-jp.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-nav.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-toggle.js"></script>
<script src="{{ asset('assets') }}/admin/js/ui-client.js"></script>